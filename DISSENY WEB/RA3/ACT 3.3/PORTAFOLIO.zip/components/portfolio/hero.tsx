"use client"

import { ArrowDown } from "lucide-react"

export function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-6 pt-20 overflow-hidden">
      {/* Background subtle grid */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(var(--foreground) 1px, transparent 1px), linear-gradient(90deg, var(--foreground) 1px, transparent 1px)`,
        backgroundSize: '80px 80px',
      }} />

      <div className="relative z-10 flex flex-col items-center text-center">
        {/* Stacked layered typography */}
        <div className="relative mb-8">
          <h1 className="sr-only">Portfolio</h1>
          <div
            className="relative select-none opacity-0 animate-fade-up"
            aria-hidden="true"
          >
            {/* Shadow layers */}
            <span className="absolute top-3 left-3 text-[clamp(3rem,12vw,10rem)] font-extrabold leading-none tracking-tighter text-accent/15">
              PORTFOLIO
            </span>
            <span className="absolute top-1.5 left-1.5 text-[clamp(3rem,12vw,10rem)] font-extrabold leading-none tracking-tighter text-accent/30">
              PORTFOLIO
            </span>
            {/* Main text */}
            <span className="relative text-[clamp(3rem,12vw,10rem)] font-extrabold leading-none tracking-tighter text-foreground">
              PORTFOLIO
            </span>
          </div>
        </div>

        <p className="mb-4 max-w-lg text-lg text-muted-foreground leading-relaxed opacity-0 animate-fade-up animate-delay-200">
          Full-stack developer crafting elegant, performant digital experiences with modern web technologies.
        </p>

        <p className="mb-10 text-sm font-mono text-accent opacity-0 animate-fade-up animate-delay-300">
          React / Next.js / Node.js / TypeScript
        </p>

        <a
          href="#projects"
          className="group relative inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-sm font-medium text-primary-foreground transition-all duration-300 hover:shadow-[0_8px_30px_rgba(74,124,219,0.3)] opacity-0 animate-fade-up animate-delay-400"
        >
          View My Work
          <ArrowDown className="h-4 w-4 transition-transform duration-300 group-hover:translate-y-0.5" />
        </a>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-0 animate-fade-in animate-delay-600">
        <span className="text-xs text-muted-foreground font-mono">scroll</span>
        <div className="h-10 w-[1px] bg-border relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-accent animate-[scroll-line_2s_ease-in-out_infinite]" />
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll-line {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(200%); }
        }
      `}</style>
    </section>
  )
}
