"use client"

import { useEffect, useRef, useState } from "react"
import { ArrowUpRight, Github, Linkedin, Twitter } from "lucide-react"

export function Contact() {
  const ref = useRef<HTMLElement>(null)
  const [visible, setVisible] = useState(false)
  const [activeFields, setActiveFields] = useState<Set<string>>(new Set())

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true)
      },
      { threshold: 0.1 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={ref}
      id="contact"
      className="relative mx-auto max-w-6xl px-6 py-28 md:py-36"
    >
      <div className={`transition-all duration-1000 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        <div className="grid gap-16 md:grid-cols-2">
          {/* Left */}
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-accent mb-4 block">
              Get in Touch
            </span>
            <h2 className="text-4xl font-bold tracking-tight text-foreground md:text-5xl text-balance mb-6">
              {"Let's Connect"}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-10 max-w-md">
              {"Have a project in mind or just want to chat about the latest in web development? I'd love to hear from you."}
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-all duration-200 hover:border-accent hover:text-accent hover:shadow-[0_4px_16px_rgba(74,124,219,0.15)]"
                aria-label="GitHub profile"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-all duration-200 hover:border-accent hover:text-accent hover:shadow-[0_4px_16px_rgba(74,124,219,0.15)]"
                aria-label="LinkedIn profile"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-all duration-200 hover:border-accent hover:text-accent hover:shadow-[0_4px_16px_rgba(74,124,219,0.15)]"
                aria-label="Twitter profile"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Right - Form */}
          <form
            onSubmit={(e) => e.preventDefault()}
            className="flex flex-col gap-6"
            aria-label="Contact form"
          >
            {(["name", "email", "message"] as const).map((field) => (
              <div key={field} className="relative">
                <label
                  htmlFor={field}
                  className={`pointer-events-none absolute left-0 transition-all duration-200 text-sm ${
                    activeFields.has(field)
                      ? "-top-5 text-xs text-accent"
                      : "top-3 text-muted-foreground"
                  }`}
                >
                  {field.charAt(0).toUpperCase() + field.slice(1)}
                </label>
                {field === "message" ? (
                  <textarea
                    id={field}
                    rows={4}
                    className="w-full resize-none border-b-2 border-border bg-transparent pb-2 pt-3 text-foreground outline-none transition-colors duration-200 focus:border-accent placeholder-transparent"
                    onFocus={() => setActiveFields((prev) => new Set(prev).add(field))}
                    onBlur={(e) => {
                      if (!e.target.value) setActiveFields((prev) => {
                        const next = new Set(prev)
                        next.delete(field)
                        return next
                      })
                    }}
                    placeholder={field}
                  />
                ) : (
                  <input
                    id={field}
                    type={field === "email" ? "email" : "text"}
                    className="w-full border-b-2 border-border bg-transparent pb-2 pt-3 text-foreground outline-none transition-colors duration-200 focus:border-accent placeholder-transparent"
                    onFocus={() => setActiveFields((prev) => new Set(prev).add(field))}
                    onBlur={(e) => {
                      if (!e.target.value) setActiveFields((prev) => {
                        const next = new Set(prev)
                        next.delete(field)
                        return next
                      })
                    }}
                    placeholder={field}
                  />
                )}
              </div>
            ))}

            <button
              type="submit"
              className="group mt-2 inline-flex w-fit items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-sm font-medium text-primary-foreground transition-all duration-300 hover:shadow-[0_8px_30px_rgba(74,124,219,0.3)]"
            >
              Send Message
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}
