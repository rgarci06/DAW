"use client"

import { useEffect, useRef, useState } from "react"

const technologies = [
  { name: "React", category: "Frontend" },
  { name: "Next.js", category: "Framework" },
  { name: "TypeScript", category: "Language" },
  { name: "Node.js", category: "Backend" },
  { name: "PostgreSQL", category: "Database" },
  { name: "Tailwind CSS", category: "Styling" },
  { name: "GraphQL", category: "API" },
  { name: "Docker", category: "DevOps" },
  { name: "AWS", category: "Cloud" },
  { name: "Prisma", category: "ORM" },
  { name: "Redis", category: "Cache" },
  { name: "Figma", category: "Design" },
]

export function TechStack() {
  const ref = useRef<HTMLElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true)
      },
      { threshold: 0.1 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={ref}
      id="expertise"
      className="relative mx-auto max-w-6xl px-6 py-28 md:py-36"
    >
      <div className={`transition-all duration-1000 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        <div className="mb-16 max-w-xl">
          <span className="text-xs font-mono uppercase tracking-widest text-accent mb-4 block">
            The Developer Edge
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
            Expertise
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            A curated set of technologies I use to build exceptional digital products, from concept to deployment.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {technologies.map((tech, index) => (
            <div
              key={tech.name}
              className="group relative flex flex-col items-center gap-2 rounded-xl border border-border bg-card px-4 py-5 transition-all duration-300 hover:border-accent hover:shadow-[0_4px_20px_rgba(74,124,219,0.15)] hover:-translate-y-1"
              style={{
                transitionDelay: visible ? `${index * 50}ms` : "0ms",
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(16px)",
              }}
            >
              <span className="text-sm font-semibold text-foreground transition-colors group-hover:text-accent">
                {tech.name}
              </span>
              <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                {tech.category}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
