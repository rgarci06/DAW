"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

export function About() {
  const ref = useRef<HTMLElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true)
      },
      { threshold: 0.15 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={ref}
      id="about"
      className="relative mx-auto max-w-6xl px-6 py-28 md:py-36"
    >
      <div className={`grid gap-12 md:grid-cols-2 md:gap-16 items-center transition-all duration-1000 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        {/* Text */}
        <div className="order-2 md:order-1">
          <span className="text-xs font-mono uppercase tracking-widest text-accent mb-4 block">
            About Me
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground mb-6 text-balance md:text-4xl">
            Building the web,{" "}
            <span className="text-accent">one pixel at a time.</span>
          </h2>
          <div className="space-y-4 text-muted-foreground leading-relaxed">
            <p>
              {"I'm Alex, a full-stack developer with 6+ years of experience building scalable web applications. I specialize in React ecosystems, crafting performant user interfaces backed by robust server architectures."}
            </p>
            <p>
              {"My approach blends clean code principles with an obsessive attention to design detail. I believe great software is invisible \u2014 it just works, beautifully."}
            </p>
            <p>
              {"When I'm not coding, you'll find me exploring typography, contributing to open-source projects, or perfecting my pour-over coffee technique."}
            </p>
          </div>
          <div className="mt-8 flex gap-8">
            <div>
              <p className="text-2xl font-bold text-foreground">6+</p>
              <p className="text-sm text-muted-foreground">Years Experience</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">50+</p>
              <p className="text-sm text-muted-foreground">Projects Delivered</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">20+</p>
              <p className="text-sm text-muted-foreground">Open Source</p>
            </div>
          </div>
        </div>

        {/* Portrait */}
        <div className="order-1 md:order-2 flex justify-center">
          <div className="relative">
            <div className="absolute -inset-4 rounded-2xl bg-accent/10 blur-2xl" />
            <div className="relative overflow-hidden rounded-2xl border border-border shadow-xl">
              <Image
                src="/images/portrait.jpg"
                alt="Alex Chen, full-stack developer"
                width={440}
                height={540}
                className="object-cover grayscale-[30%] transition-all duration-500 hover:grayscale-0"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
