"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { ArrowUpRight, Github } from "lucide-react"

const projects = [
  {
    title: "Pulse Analytics",
    description: "Real-time SaaS analytics dashboard with customizable widgets, team collaboration, and automated reporting.",
    tags: ["Next.js", "PostgreSQL", "D3.js", "Tailwind"],
    image: "/images/project-1.jpg",
    liveUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Luxe Commerce",
    description: "Premium headless e-commerce platform with advanced product filtering, wishlist, and seamless checkout.",
    tags: ["React", "Node.js", "Stripe", "GraphQL"],
    image: "/images/project-2.jpg",
    liveUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Thread Social",
    description: "Modern social platform with real-time messaging, content feeds, and AI-powered content moderation.",
    tags: ["Next.js", "Redis", "WebSocket", "AWS"],
    image: "/images/project-3.jpg",
    liveUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Muse Writer",
    description: "AI-powered writing tool with collaborative editing, version history, and intelligent content suggestions.",
    tags: ["TypeScript", "OpenAI", "Prisma", "React"],
    image: "/images/project-4.jpg",
    liveUrl: "#",
    githubUrl: "#",
  },
]

export function Projects() {
  const ref = useRef<HTMLElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true)
      },
      { threshold: 0.05 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={ref}
      id="projects"
      className="relative mx-auto max-w-6xl px-6 py-28 md:py-36"
    >
      <div className={`transition-all duration-1000 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        <div className="mb-16 max-w-xl">
          <span className="text-xs font-mono uppercase tracking-widest text-accent mb-4 block">
            Selected Work
          </span>
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
            Projects
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            A selection of recent projects that showcase my approach to building modern, scalable web applications.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {projects.map((project, index) => (
            <article
              key={project.title}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card transition-all duration-500 hover:shadow-xl hover:border-accent/30"
              style={{
                transitionDelay: visible ? `${index * 100}ms` : "0ms",
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(30px)",
              }}
            >
              {/* Image */}
              <div className="relative aspect-[16/10] overflow-hidden">
                <Image
                  src={project.image}
                  alt={`${project.title} project screenshot`}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-primary/60 flex items-center justify-center gap-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <a
                    href={project.liveUrl}
                    className="flex items-center gap-2 rounded-full bg-primary-foreground px-5 py-2.5 text-sm font-medium text-primary transition-transform hover:scale-105"
                    aria-label={`View ${project.title} live`}
                  >
                    View Live
                    <ArrowUpRight className="h-4 w-4" />
                  </a>
                  <a
                    href={project.githubUrl}
                    className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-foreground/20 text-primary-foreground transition-transform hover:scale-110 hover:bg-primary-foreground/30"
                    aria-label={`View ${project.title} on GitHub`}
                  >
                    <Github className="h-4 w-4" />
                  </a>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-card-foreground mb-2">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-border px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
