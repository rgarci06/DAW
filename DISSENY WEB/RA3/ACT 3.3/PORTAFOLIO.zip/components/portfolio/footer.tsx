export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 md:flex-row">
        <p className="text-sm text-muted-foreground">
          {"© 2026 Alex Chen. Crafted with care."}
        </p>
        <p className="text-xs font-mono text-muted-foreground/60">
          Built with Next.js & Tailwind CSS
        </p>
      </div>
    </footer>
  )
}
